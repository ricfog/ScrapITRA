# ScrapITRA

Scraping the website of the Internation Trail Running Association (ITRA) with Python.

A presentation of the package with some examples is available <a href=https://github.com/ricfog/ScrapITRA/blob/master/Presentation.pdf>here</a>.

The package can be installed via <code>pip install</code> after downloading the <code>.tar.gz</code> file in the <code>dist/</code> folder. <br/>
  Alternatively, the functions in the <code>scrapITRA/src</code> folder can be used without instalation by copying/forking the repository.
